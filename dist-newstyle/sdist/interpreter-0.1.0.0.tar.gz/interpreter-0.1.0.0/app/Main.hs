module Main (main) where

import Data.Hashable
import Data.Time.Clock
import Data.Char

answerPath :: FilePath
answerPath = "answer.txt"

data Direction = DUp | DDown | DLeft | DRight
    deriving (Eq, Show, Read)

data Mode = ModeNormal | ModeSymbol
    deriving (Eq, Show, Read)

data Cmd = MvUp | MvDw | MvLf | MvRt | MvLfRt | MvUpDw | MvRnd | MvTrm | End | Dupe | Swap | Drop | Prnt | Skip | Put Int
    deriving (Eq, Show, Read)

charToCmd :: Char -> Cmd
charToCmd '?' = MvRnd
charToCmd '#' = MvTrm
charToCmd '@' = End
charToCmd ':' = Dupe
charToCmd '\\' = Swap
charToCmd '$' = Drop
charToCmd '.' = Prnt
charToCmd ' ' = Skip
charToCmd c = Put (digitToInt c)

rndDir:: g -> (Direction, g)
rndDir g
    | num = 1 == (DUp, ng)
    | num = 2 == (DDown, ng)
    | num = 3 == (DLeft, ng)
    | num = 4 == (DRight, ng)
        where (num, ng) = next g

move :: Direction -> [[Char]] -> [[Char]]
move DUp x = (last x : init x)
move DDown (y:ty) = ty ++ [y]
move DLeft c = map (\ x -> (last x : init x)) c
move DRight c = map (\ (x:tx) -> (tx ++ [x])) c
move _ c = c

cngMode :: Mode -> Mode
cngMode ModeNormal = ModeSymbol
cngMode ModeSymbol = ModeNormal

exec :: Direction -> Mode -> [Int] -> [[Char]] -> g -> [Char]
exec dir mode stack (('"':tx):ty) g = exec dir (cngMode mode) stack (move dir (('"':tx):ty)) g
exec _ ModeNormal (s:ts) (('-':tx):ty) g
    | s == 0 = exec DLeft ModeNormal (s:ts) (move DLeft (('-':tx):ty)) g
    | otherwise = exec DRight ModeNormal (s:ts) (move DRight (('-':tx):ty)) g
exec _ ModeNormal (s:ts) (('|':tx):ty) g
    | s == 0 = exec DUp ModeNormal (s:ts) (move DUp (('-':tx):ty)) g
    | otherwise = exec DDown ModeNormal (s:ts) (move DDown (('-':tx):ty)) g
exec dir ModeNormal (s:ts) ((c:tx):ty) g
    | c == ' ' = exec dir ModeNormal (s:ts) (move dir ((c:tx):ty)) g
    | c == '^' = exec DUp ModeNormal (s:ts) (move DUp ((c:tx):ty)) g
    | c == 'v' = exec DDown ModeNormal (s:ts) (move DDown ((c:tx):ty)) g
    | c == '<' = exec DLeft ModeNormal (s:ts) (move DLeft ((c:tx):ty)) g
    | c == '>' = exec DRight ModeNormal (s:ts) (move DRight ((c:tx):ty)) g
    | c == '?' = exec newDir ModeNormal (s:ts) (move newDir ((c:tx):ty)) ng
    | c == '.' = (show s) ++ exec dir ModeNormal ts (move dir ((c:tx):ty)) g
    | c == ',' = (chr s) : exec dir ModeNormal ts (move dir ((c:tx):ty)) g
    | c == '@' = ""
        where (newDir, ng) = randomR (1, 4) g
exec dir ModeNormal stack (((ch):tx):ty) g = exec dir ModeNormal ((digitToInt ch):stack) (move dir ((ch:tx):ty)) g
exec dir ModeSymbol stack (((ch):tx):ty) g = exec dir ModeSymbol ((ord ch):stack) (move dir ((ch:tx):ty)) g
exec a b c d e = "\n\t<error>\n\n" ++ (show a) ++ '\n' : (show b) ++ '\n' : (show c) ++ '\n' : (show d) ++ '\n' : (show e)

-- (show ((c:tx):ty)) ++ "\n" ++ 

main :: IO ()
main = do
    rnd <- getCurrentTime
    ans <- readFile answerPath
    putStrLn $ exec DRight ModeNormal [0] g $ lines ans